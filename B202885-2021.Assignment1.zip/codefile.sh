#!/usr/bin/bash

# This is the file that carries out the assignment

	#TASK 1: perform a quality check - we run fastqc on the paired-end raw sequence data to obtain data for further analysis. 

#1) Descend into directory with fastq data

cd ~

java -version

#NB: first check if you	have the correct java version -	if not, you will see an error and need to download java (1.6 or later)

cp -r /localdisk/data/BPSM/AY21/fastq $HOME

#2) change directories

cd $HOME/fastq

#3) Make new directory for outputs of fastqc

mkdir fastqc_res

#4) Run fastqc & redirect standard output to "stdout.log", redirect standard error to "stderr.log"

fastqc -q -o fastqc_res --extract *.fq.gz

	#TASK 2: We now want to assess the sequences: we want to assess the numbers and quality of the raw sequence data

#1) First return to the home directory

cd $HOME

#2) We now make a file with all the summary.txt outputs, which are located in $HOME/fastq/fastqc_res/*_fastqc/summary.txt

cat $HOME/fastq/fastqc_res/*_fastqc/summary.txt > mergedfile

#3) A sequence passes the quality check if 'basic statistics', 'per base sequence quality' and 'sequence length distribution' ALL PASS
# we need both read 1 and read 2 to pass for that specific clone/time/replicate to pass. 

# The file structure of 'mergedfile' is such that every 20 lines, we have a new clone/time/replicate. First 10 lines are read 1, then 2. 

# first extract all the sequences that pass 'basic statistics':  

cat mergedfile | awk 'NR %10 == 1' | awk '{FS="\t";if($1 == "PASS"){print $3;}}' |sed 's/_.*.fq.gz//g' | tail -n +2 > passed_sequences

# Add in the first file if it passes (for some reason, an extra tab is inserted in the first line...)

cat mergedfile | head -n 1 | awk '{FS="\t";if($1 == "PASS"){print $4;}}' |sed 's/_.*.fq.gz//g' >> passed_sequences

# now extract all the sequences	that pass 'per base seq	quality'.

cat mergedfile | awk 'NR %10 == 2' | awk '{FS="\t";if($1 == "PASS"){print $3;}}' |sed 's/_.*.fq.gz//g' | tail -n +2 >> passed_sequences

# Add in the first file if it passes (for some reason, an extra	tab is inserted	in the first line...)

cat mergedfile | head -n 2 | tail -n +2 | awk '{FS="\t";if($1 == "PASS"){print $6;}}' |sed 's/_.*.fq.gz//g' >> passed_sequences

# now extract all the sequences that pass "seq length distribution"

cat mergedfile | awk 'NR %10 == 7' | awk '{FS="\t";if($1 == "PASS"){print $3;}}' |sed 's/_.*.fq.gz//g' | tail -n +2 >> passed_sequences

# now add in the first file it is passes

cat mergedfile | head -n 7 | tail -n +7 | awk '{FS="\t";if($1 == "PASS"){print $5;}}'|sed 's/_.*.fq.gz//g' >> passed_sequences

# 4) If a sequences passes quality check, it will exist 6 times in the file:

sort -d passed_sequences | uniq -c | awk '{FS=" ";if($1 == "6"){print $2;}}' >> passed_sequences_final

# We now have all the sequences that pass the quality check. We also want the number of sequences that pass our quality check. 

sort -d passed_sequences | uniq -c | awk '{FS=" ";if($1 == "6"){print $2;}}' | wc -l >> passed_sequences_final

	# TASK 3: Align the read pairs to the T. Congolese genome. 

# First need to undo the gzip compression, using gunzip

cd $HOME/fastq

# We need to unzip the fasta file too:

cp /localdisk/data/BPSM/AY21/Tcongo_genome/TriTrypDB-46_TcongolenseIL3000_2019_Genome.fasta.gz $HOME/fastq

gunzip TriTrypDB-46_TcongolenseIL3000_2019_Genome.fasta.gz

# Need to build a Bowtie2 index

bowtie2-build TriTrypDB-46_TcongolenseIL3000_2019_Genome.fasta tcongolese_index

# create a file with all the filenames for our bowtie loop

ls *.fq.gz >> filenames.txt
sed 's/.\{7\}$//' filenames.txt | uniq >> shortfilenames.txt

# Now create a loop that will align each pair of reads in the same row: 

while read line;
do
bowtie2 -x tcongolese_index -1 ${line}1.fq.gz -2 ${line}2.fq.gz -S ${line}.sam
done < shortfilenames.txt 

# convert sam files to bam files

while read line;
do
samtools view -S -b ${line}.sam > ${line}.bam
done < shortfilenames.txt

	# TASK 4: Generate counts data

cp /localdisk/data/BPSM/AY21/TriTrypDB-46_TcongolenseIL3000_2019.bed $HOME/fastq

# First need to sort the bam files:
# Then we need to index them:
# Then create a $filename.bai file for each bam file

while read line;
do
samtools sort ${line}.bam -o sorted${line}.bam
samtools index -b sorted${line}.bam
bedtools multicov -bams sorted${line}.bam -bed TriTrypDB-46_TcongolenseIL3000_2019.bed >> countsdata${line}.txt
done < shortfilenames.txt

# The resulting file gives the counts for each gene for each experiment (there are many!). 

	# TASK 5: we create output files that tell us the average number of counts per gene. 

# To calculate the average nr of counts per gene, we want (the total nr counts for gene i)/(nr of gene i data)

# genenum is the number of genes in the bedfile. 

genenum=$(wc -l TriTrypDB-46_TcongolenseIL3000_2019.bed | awk '{print $1}')

# We now iterate over the type of gene, and add all the counts together, and divide them by 45 (the number of experiments)
# We will create a file with gene name, description and total counts. First we output all the count data for each group.
# We know that there are three in each group (though we might now know this necessarily!) But I didn't know how to 
# make three nested for loops in awk, or how to make a loop that chooses...

tail -n +2 100k.fqfiles | sort -k2,2 -k4,4 -k5,5

# This creates 15 files with the filenames that are in each group
# Now we combine the data for each experiment into one big text file (per experiment). This will make it easier to analyse. 

for i in 1 2 3; do cat countsdata100k.C1-$i-50* >> compiled-C1-0-uninduced; done
for i in 1 2 3; do cat countsdata100k.C1-$i-51* >> compiled-C1-24-induced; done
for i in 4 5 6; do cat countsdata100k.C1-$i-51* >> compiled-C1-24-uninduced; done
for i in 1 2 3; do cat countsdata100k.C1-$i-53* >> compiled-C1-48-induced; done
for i in 4 5 6; do cat countsdata100k.C1-$i-53* countsdata100k.C1-$i-54* >> compiled-C1-48-uninduced; done

for i in 1 2 3; do cat countsdata100k.C2-$i-50* >> compiled-C2-0-uninduced; done
for i in 1 2 3; do cat countsdata100k.C2-$i-51* countsdata100k.C2-$i-52* >> compiled-C2-24-induced; done
for i in 4 5 6; do cat countsdata100k.C2-$i-52* >> compiled-C2-24-uninduced; done
for i in 1 2 3; do cat countsdata100k.C2-$i-54* >> compiled-C2-48-induced; done
for i in 4 5 6; do cat countsdata100k.C2-$i-54* >> compiled-C2-48-uninduced; done

for i in 1 2 3; do cat countsdata100k.WT-$i-50* countsdata100k.WT-$i-51* >> compiled-WT-0-uninduced; done
for i in 1 2 3; do cat countsdata100k.WT-$i-52* >> compiled-WT-24-induced; done
for i in 4 5 6; do cat countsdata100k.WT-$i-53* >> compiled-WT-24-uninduced; done
for i in 1 2 3; do cat countsdata100k.WT-$i-55* >> compiled-WT-48-uninduced; done
for i in 1 2 3; do cat countsdata100k.WT-$i-55* >> compiled-WT-48-induced; done
for i in 4 5 6; do cat countsdata100k.WT-$i-55* >> compiled-WT-48-uninduced; done

i=1
end=3
while [ $i -le $end ]; 
do 
cat compiled* | awk "NR %$genenum == $i" | awk 'BEGIN{FS="\t"; sum=0} {sum+=$6} END{print sum}' >> counts_compiled; 
i=$(($i+1)); 
done

# Create a variable which is the number of experiments run using bedtools (in our case, all as all pass the quality check). 

expnum=$(ls *_.bam.bai | wc -l)

# Divide every line by expnum (#of experiments). For some reason it keeps outputting division by 0, so we manually input 45. 

awk '{for(i=1;i<=NF;i++){$i=$i/3}} 1' counts_compiled >> counts_average_column

# Next we put the gene name and description in the file 'counts_average_column'
# First make a file containing the gene names and descriptions. 

head -n $genenum countsdata.txt | awk -F'\t' '{print $4,$5}' >> counts_descript

paste counts_average_column counts_descript | column -s $'\t' -t >> counts_average_final

# The file 'counts_average_final' gives us total gene expression levels for each gene, gene name and gene description. 

# We now want gene expression levels for each group: C1, C2 and WT.
# We sort the files by time, sample, induced/non-induced: we will get 3 x 3 x 2 = 18 groups
# We only want to count specific files:


numcloneone=$(ls *C1*.bam.bai | wc -l)
numclonetwo=$(ls *C2*.bam.bai | wc -l)
numwildtype=$(ls *WT*.bam.bai | wc -l)

	# TASK 6: Fold-change data for each group -- didn't have time for this...
